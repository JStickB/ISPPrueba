﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApriPrueba.Dto;
using WebApriPrueba.Entities;

namespace WebApriPrueba.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductoController : ControllerBase
    {
        private readonly PruebatecnicaispContext _context;

        public ProductoController(PruebatecnicaispContext context)
        {
            _context = context;
        }


        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var objeto = await _context.Productos.ToListAsync();
                return Ok(objeto);
            }
            catch (Exception ex)
            {

                return BadRequest(ex.Message);
            }
        }


        [HttpPost]
        public async Task<IActionResult> Post(ProductoDto producto)
        {
            try
            {
                Producto prod = new Producto();
                prod.Nombre = producto.Nombre;
                prod.Precio = producto.Precio;
                prod.Fechacreacion = DateTime.Now;
                await _context.Productos.AddAsync(prod);
                _context.SaveChanges();
                return Ok(prod.Id);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
                throw;
            }
        }
    }
}
