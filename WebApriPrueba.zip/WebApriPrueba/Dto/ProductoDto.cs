﻿namespace WebApriPrueba.Dto
{
    public class ProductoDto
    {
        public string? Nombre { get; set; }

        public decimal? Precio { get; set; }
    }
}
