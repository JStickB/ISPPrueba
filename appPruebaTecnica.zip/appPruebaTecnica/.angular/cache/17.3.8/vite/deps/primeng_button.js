import {
  Button,
  ButtonDirective,
  ButtonModule
} from "./chunk-APMWTD2X.js";
import "./chunk-H2J3WXS7.js";
import "./chunk-MRUW4HX5.js";
import "./chunk-2QDPCBAK.js";
export {
  Button,
  ButtonDirective,
  ButtonModule
};
//# sourceMappingURL=primeng_button.js.map
