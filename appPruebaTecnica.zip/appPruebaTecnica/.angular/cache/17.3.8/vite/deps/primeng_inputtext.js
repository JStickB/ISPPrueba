import {
  InputText,
  InputTextModule
} from "./chunk-Y2PM3OVU.js";
import "./chunk-KMVHIWTZ.js";
import "./chunk-H2J3WXS7.js";
import "./chunk-MRUW4HX5.js";
import "./chunk-2QDPCBAK.js";
export {
  InputText,
  InputTextModule
};
//# sourceMappingURL=primeng_inputtext.js.map
