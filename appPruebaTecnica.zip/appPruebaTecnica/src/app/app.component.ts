import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';

import { HttpClientModule } from '@angular/common/http';
import { ProductoService } from './services/producto.service';

import { TableModule } from 'primeng/table';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';

import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, HttpClientModule, TableModule, InputTextModule, ButtonModule, ReactiveFormsModule],
  providers: [ProductoService],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  
  title = 'appPruebaTecnica';
  productos = [];

  constructor(private productoServicio: ProductoService){}

  ngOnInit(): void {
    // throw new Error('Method not implemented.');
    this.ConsultarDatos();
  }



//CONSULTANDO PRODUCTOS
  ConsultarDatos():void {    
    this.productoServicio.ObtenerProducto().subscribe(
      data => {
        this.productos = data;
        console.log(data);                
      }      
    );
  }

  //GUARDANDO DATOS PRODUCTOS
  GuardarDatos():void {
    //FALTA ENVIAR LOS DATOS DEL FORMULARIO, NO RECUERDO COMO USAR LOS FORMULARIOS REACTIVOS, POR AHORA USARE HARDCODE...
    let prod  = { nombre: "LENTES RAYBAN", precio: 3500 };
    this.productoServicio.GuardarProducto(prod).subscribe(
      data => {        
        console.log(data);                
      }      
    );
    console.log("hola mundo");
    this.ConsultarDatos();
  }

}
